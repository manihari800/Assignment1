const express = require('express');
const router = express.Router();
const Task = require('../schema/taskschema'); // Import the MongoDB model you created

// Route to add a new task
router.post('/tasks', (req, res) => {
    const { title, priority, dueDate, labels } = req.body;
  
    // Create a new task and add it to the database, associated with the user
    const newTask = new Task({
      title,
      priority,
      dueDate,
      labels,
    });
  
    newTask.save((err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to add the task' });
      }
      res.status(201).json({ message: 'Task added successfully' });
    });
  });

// Update the priority and due date of a task
router.put('/tasks/:taskId', (req, res) => {
    const { priority, dueDate } = req.body;
    const taskId = req.params.taskId;
    // Find the task by ID and update priority and due date
    Task.findByIdAndUpdate(
        taskId,
        { $set: { priority, dueDate } },
        { new: true },
        (err, updatedTask) => {
            if (err) {
                return res.status(500).json({ error: 'An error occurred' });
            }
            res.json(updatedTask);
        }
    );
});

// Update the status of a task (completed or in progress)
router.put('/tasks/:taskId/status', (req, res) => {
    const { status } = req.body;
    const taskId = req.params.taskId;
    // Find the task by ID and update the status
    Task.findByIdAndUpdate(
        taskId,
        { $set: { status } },
        { new: true },
        (err, updatedTask) => {
            if (err) {
                return res.status(500).json({ error: 'An error occurred' });
            }
            res.json(updatedTask);
        }
    );
});

// Add a label to a task
router.post('/tasks/:taskId/labels', (req, res) => {
    const { label } = req.body;
    const taskId = req.params.taskId;
    // Find the task by ID and add the label
    Task.findByIdAndUpdate(
        taskId,
        { $push: { labels: label } },
        { new: true },
        (err, updatedTask) => {
            if (err) {
                return res.status(500).json({ error: 'An error occurred' });
            }
            res.json(updatedTask);
        }
    );
});

/// Route to delete a task
router.delete('/tasks/:taskId', (req, res) => {
    const taskId = req.params.taskId;
  
    // Delete the specified task from the database
    Task.findByIdAndRemove(taskId, (err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to delete the task' });
      }
      res.status(200).json({ message: 'Task deleted successfully' });
    });
  });

// Route to search and filter tasks
router.get('/tasks', (req, res) => {
    const { title, dueDate, priority, labels } = req.query;
  
    const query = {};
  
    if (title) {
      query.title = new RegExp(title, 'i'); // Case-insensitive search
    }
  
    if (dueDate) {
      query.dueDate = dueDate;
    }
  
    if (priority) {
      query.priority = priority;
    }
  
    if (labels) {
      query.labels = labels;
    }
  
    // Fetch tasks that match the query
    Task.find(query, (err, tasks) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to fetch tasks' });
      }
      res.status(200).json({ tasks });
    });
  });
module.exports = router;