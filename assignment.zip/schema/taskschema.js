const mongoose = require('mongoose');
const TaskSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  priority: {
    type: String,
    enum: ['high', 'medium', 'low'],
  },
  dueDate: Date,
  status: {
    type: String,
    enum: ['in progress', 'completed'],
    default: 'in progress',
  },
  labels: [String],
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
});
  
  const Task = mongoose.model('Task', TaskSchema);
  module.exports  = Task;