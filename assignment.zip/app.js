
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const authRouter = require('./routers/authRoutes');
const taskRouter = require('./routers/taskRouter');
app.use(express.json());
app.set('view engine', 'ejs'); // Set EJS as the template engine
app.set('views', path.join(__dirname, 'views')); // Set the 'views' directory
mongoose.set('strictQuery', true);

// Connect to MongoDB (you need to set up a MongoDB instance and replace the connection string)
mongoose.connect('mongodb+srv://manihari:Mani1234@cluster0.gtc54hl.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

app.use('/',authRouter); 
app.use('/',taskRouter);
app.get('/dashboard',(req,res)=>{
    res.render('dashboard',{taskRouter});
})
// Start the server
app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});